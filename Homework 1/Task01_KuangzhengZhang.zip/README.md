1. Double Click `2.00.betterDotsAndLines.html`
2. Choose any OBJ in `./obj`
3. `./img` contains front and rear images of `shuttle.obj` captured by Windows 3D Viewer